<template>
  <div class="exception"
       :style="StyleHeight">
    <div class="img">
      <img :src="config[type].img" />
      <!--<div class="ele" :style="{backgroundImage: `url(${config[type].img})`}"/>-->
    </div>
    <!-- <div class="content">
      <h1>{{config[type].title}}</h1>
      <div class="desc">{{config[type].desc}}</div>
      <div class="action">
        <a-button type="primary">返回首页</a-button>
      </div>
    </div> -->
  </div>
</template>

<script>
import Config from './typeConfig'

export default {
  name: 'ExceptionPage',
  props: ['type'],
  data () {
    return {
      config: Config
    }
  },
  computed: {
    StyleHeight () {
      let style = {}
      style.height = window.screen.availHeight - 240 + 'px'
      return style
    }
  }
}
</script>

<style lang="less">
.exception {
  min-height: 500px;
  align-items: center;
  text-align: center;
  background: #fff;
  height: 100%;
  padding: 60px 0;
  display: flex;
  justify-content: center;
  align-items: center;
  .img {
    display: inline-block;
    height: 100%;
    padding-right: 52px;
    zoom: 1;
    img {
      // width: 550px;
      height: 100%;
    }
  }
  .content {
    display: inline-block;
    flex: auto;
    h1 {
      color: #434e59;
      font-size: 72px;
      font-weight: 600;
      line-height: 72px;
      margin-bottom: 24px;
    }
    .desc {
      color: rgba(0, 0, 0, 0.45);
      font-size: 20px;
      line-height: 28px;
      margin-bottom: 16px;
    }
  }
}
</style>
