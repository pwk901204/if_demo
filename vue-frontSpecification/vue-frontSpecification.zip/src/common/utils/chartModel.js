import echarts from 'echarts'
let chartModel = {
  // 初始化图表
  initCharts: (id, option) => {
    let dom = document.getElementById(id)
    let chart = echarts.init(dom);
    chart.setOption(option, true);
    window.addEventListener('resize',() => {
      chart.resize();
    },false);
  },
  // 获取图标实例
  getCharts: (id) => {
    let dom = document.getElementById(id)
    let chart = echarts.init(dom)
    return chart
  },
  // 渲染图标,已有实例
  initChartsByChart: (chart, option) => {
    chart.setOption(option, true);
    window.addEventListener('resize',() => {
      chart.resize();
    },false);
  },
  // 地图注册
  registMapForCharts: (name, geoJson) => {
    echarts.registerMap(name, geoJson)
  },
  // 折线图 / 柱状图
  lineChartsOption: (data) => {
    let option = {
      color: data.color || {},
      grid: {
        left : '3%',   //组件离容器左侧的距离
        top:'40px',
        right : '40px',
        bottom : '20px',
        containLabel : true     //grid 区域是否包含坐标轴的刻度标签
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: "cross",
          label: {
            backgroundColor: "#6a7985"
          }
        }
      },
      xAxis: {
        type: 'category',
        boundaryGap: false,            
        axisTick: {
            show: false
        },
        interval:0,
        axisLabel: {
              show: true,
              interval:0,
              formatter: function (value) {
                let _val = sessionStorage.getItem('xAxisName') || ''
                if (_val === value) {
                  return ''
                } else {
                  sessionStorage.setItem('xAxisName', value)
                  return value
                }
              },
              textStyle: {
                  color: 'black'
              }
        },
        axisLine:{
            symbol:['none','arrow'],
            lineStyle:{
                color:'#ced7e2'
            }
        }, 
        data: data.xAxisLabel
      },
      yAxis: {
        splitLine:{show:false},  
        axisTick: {
            show: false
        },
        axisLabel: {
              show: true,
              textStyle: {
                  color: '#505364'
              }
        },
        axisLine:{
            symbol:['none','arrow'],
            lineStyle:{
                color:'#ced7e2'
            }
        }, 
        color:'red',
        type: 'value',
        scale : true
        
        // min : 0
      },
      series: [{
        name: "事件数",
        data: data.seriesData,
        type: data.charttype || 'line',
        radius:'100%',
        areaStyle: {},

        itemStyle: {
            normal: {
                color: '#3435b7'//线颜色
            }
        },
        areaStyle: {
            normal: {
                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{ //折线图颜色渐变
                    offset: 0,
                    color: '#c1c1e8'
                }, {
                    offset: 1,
                    color: '#fcfcfd'
                }])
            }
        }
      }]
    }
    return option
  },
  //饼图
  pieCharts: (data) => {
    let option = {
      color: data.color || {},
      tooltip: {
        trigger: 'item',
        formatter: '{a} <br/>{b}: {c} ({d}%)'
      },
      legend: {
        orient: 'vertical',
        top: 'middle',
        right: '40',
        data: data.legendData || []
      },
      series: [{
        name: data.name || '',
        type: 'pie',
        radius: ['30%', '58%'],
        center: ['50%', '50%'],
        label: {
          normal: {
            show: false,
            position: 'center'
          },
          emphasis: {
            show: true,
            textStyle: {
                fontSize: '16'
            }
          }
        },
        labelLine: {
          normal: {
              show: false
          }
        },
        data: data.data || []
      }]
    }
    return option
  },
  // 漏斗图
  funnelCharts: (data) => {
    let option = {
      color: data.color || [],
      tooltip: {
        trigger: 'item',
        formatter: "{a} <br/>{b}: {c} ({d}%)"
      },
      legend: {
        data: data.legendData || []
      },
      series: [
        {
          name: data.name || '',
          type:'funnel',
          left: '10%',
          top: 60,
          bottom: 60,
          width: '80%',
          min: 0,
          max: 100,
          minSize: '0%',
          maxSize: '100%',
          sort: 'descending',
          gap: 2,
          label: {
            show: true,
            position: 'inside'
          },
          labelLine: {
            length: 10,
            lineStyle: {
                width: 1,
                type: 'solid'
            }
          },
          itemStyle: {
            borderColor: '#fff',
            borderWidth: 1
          },
          data: data.data || []
        }
      ]
    }
    return option
  },
  // 仪表盘
  gaugeCharts: (data) => {
    let option = {
        color: data.color || [],
        tooltip : {
          formatter: "{a} <br/>{b} : {c}%"
        },
        series: [
          {
            name: data.name || '',
            type: 'gauge',
            min: 0,
            max: 100,
            splitLine: {
              length: 20
            },
            axisLine: {
              lineStyle: {
                width: 10,
                color: data.color ||  [[0.2, '#91c7ae'], [0.8, '#63869e'], [1, '#c23531']]
              }
            },
            detail: {formatter:'{value}%'},
            data: data.data || []
          }
        ]
    }
    return option
  },
  // 世界地图
  worldMapCharts: (data) => {
    let option = {
      tooltip: {
        trigger: 'item'
      },
      geo: {
        map: 'world',
        silent: true,
        label: {
          emphasis: {
            show: true,
            areaColor: '#eee'
          }
        },
        itemStyle: {
          normal: {
            areaColor: '#ffffff',
            borderWidth: 0.2,
            borderColor: '#32ade2'
          }
        },
        roam: true
      },
      series: []
    }
    return option
  }
}

export default chartModel
