import settings from '@/defaultSettings'
export default {
  namespaced: true,
  state: settings,
  mutations: {

  }
}
