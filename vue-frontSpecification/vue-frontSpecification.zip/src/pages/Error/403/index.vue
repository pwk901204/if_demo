<template>
  <div class="page-form">
  </div>
</template>

<script>
import GlobalMixin from '@/mixins/global'
export default {
  name: 'DemoForm', // 表单
  mixins: [GlobalMixin],
  data () {
    return {
    }
  },
  mounted () {

  },
  methods: {
  }
}
</script>
<style lang="less">
@import "./index.less";
</style>
