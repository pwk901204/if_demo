<template>
  <div class="page-header-index-wide page-chart">
    <a-row class="fly" :gutter="12">
      <a-col :span="24">
        <div class="chart-item">
          <div class="chart-title">
            <h2>流动人口地域图</h2>
          </div>
          <div class="chart-content">
            <div class="chart-chart" id="MigrationMap"></div>
          </div>
        </div>
      </a-col>
    </a-row>
  </div>
</template>

<script>
import echarts from 'echarts'
import chartModel from '@/common/utils/chartModel'
import mapData from './data'
import China from './China'
import convert from './convert'
import geoCoordMap from './geoCoordMap'
export default {
  name: 'PieChart',
  components: {
  },
  data () {
    return {
      China: China,
      mapData: mapData,
      convert: convert,
      mapIndex: 0
    }
  },
  mounted () {
    this.setPopuMigrationMap()  // 流动人口地域图
  },
  methods: {
    /**
		 * 流动人口地域图
		 */
    setPopuMigrationMap: function () {
      let dom = document.getElementById('MigrationMap')
      let echartObj = echarts.init(dom);
      // 获取geoJson
      let geoJson = China.features ? China : fly.evalJSON(China);

      echarts.registerMap('china', geoJson);

      echartObj.setOption({
        series: [{
          type: 'map',
          map: 'china'
        }]
      });


      var convertData = function (convert) {
        var res = [];
        for (var i = 0; i < convert.length; i++) {
          var dataItem = convert[i];
          var fromCoord = geoCoordMap[dataItem[0].name];
          var toCoord = geoCoordMap[dataItem[1].name];
          if (fromCoord && toCoord) {
            res.push({
              fromName: dataItem[0].name,
              toName: dataItem[1].name,
              coords: [fromCoord, toCoord]
            });
          }
        }
        return res;
      };


      var series = [];
      this.mapData.forEach(function (item, i) {
        series.push({
          name: item[0],
          type: 'lines',
          zlevel: 2,

          //线特效配置
          effect: {
            show: true,
            period: 4,
            trailLength: 0.6,
            symbol: 'circle',
            symbolSize: 6
          },
          lineStyle: {
            normal: {
              color: '#f6c54c',
              width: 1,
              opacity: 0.4,
              curveness: 0.2
            }
          },
          data: convertData(item[1])
        }, {
          type: 'scatter',
          coordinateSystem: 'geo',
          zlevel: 2,
          label: {
            normal: {
              show: true,
              textStyle: {
                color: '#4d4d4d',
                fontSize: '12',
                fontFamily: 'Microsoft YaHei'
              },
              position: 'right',
              formatter: '{b}'
            }
          },
          //终点形象
          // symbol: 'image:./map-point.png',
          //圆点大小
          symbolSize: function (val) {
            return [9, 9];
          },
          itemStyle: {
            normal: {
              color: '#224381',
              borderColor: '#1192ff',
              borderWidth: 2
            }
          },
          data: [{
            name: item[0],
            value: geoCoordMap[item[0]].concat([-1])
          }].concat(item[1].map(function (dataItem) {
            return {
              name: dataItem[0].name,
              value: geoCoordMap[dataItem[0].name].concat([dataItem[0].value])
            };
          }))

        });

      });

      var geoConfig = {
        map: 'china',
        zoom: 1.4,
        scaleLimit: {
          min: 0.5,
          max: 2
        },
        //显示文本样式
        label: {
          normal: {
            show: false,
            textStyle: {
              color: '#4c4c4c'
            }
          },
          emphasis: {
            textStyle: {
              color: '#fff'
            }
          }
        },
        tooltip: {
          show: true,
          trigger: 'item',
          formatter: function (params) {
            var addStr = '';
            if (params.data.value && params.data.value[2] > -1) {
              addStr = ' : ' + params.data.value[2] + '人';
            }

            return params.data.fromName ? (params.data.fromName + ' > ' + params.data.toName) : params.data.name + addStr;
          },
          axisPointer: {
            type: 'shadow',
          },
          backgroundColor: "rgba(255,255,255, .8)",
          borderRadius: 4,
          borderWidth: 0,
          padding: [14, 6, 16, 11],
          textStyle: {
            color: "#4c4c4c",
            fontSize: "14"
          }
        },
        //鼠标缩放和平移
        roam: true,
        itemStyle: {
          normal: {
            areaColor: '#a2c7e9',
            borderColor: '#fff'
          },
          emphasis: {
            areaColor: '#bbdeff'
          }
        }
      };

      geoConfig.center = [104.5, 34.5];

      var thisOption = {
        tooltip: {
          trigger: 'item',
          formatter: "{b}"
        },
        grid: {
          x: 80,
          y: 120,
          x2: 80,
          y2: 60
        },

        //地图相关设置
        geo: geoConfig,
        series: series
      };

      echartObj.clear();

      // 绘制图表 
      echartObj.setOption(thisOption);
    }
  }
}
</script>

<style lang="less" scoped>
@import url('./index.less');
</style>
