const convert = [
  [
    {
      'name': '河南',
      'value': '7386'
    },
    {
      'name': '芜湖'
    }
  ],
  [
    {
      'name': '江苏',
      'value': '6389'
    },
    {
      'name': '芜湖'
    }
  ],
  [
    {
      'name': '浙江',
      'value': '4319'
    },
    {
      'name': '芜湖'
    }
  ],
  [
    {
      'name': '湖北',
      'value': '4125'
    },
    {
      'name': '芜湖'
    }
  ],
  [
    {
      'name': '四川',
      'value': '3578'
    },
    {
      'name': '芜湖'
    }
  ],
  [
    {
      'name': '山东',
      'value': '3344'
    },
    {
      'name': '芜湖'
    }
  ],
  [
    {
      'name': '河北',
      'value': '3005'
    },
    {
      'name': '芜湖'
    }
  ]
]

export default convert
