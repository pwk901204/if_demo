<template>
  <div class="page-header-index-wide page-chart">
    <a-row class="fly" :gutter="12">
      <a-col :span="12">
        <div class="chart-item">
          <div class="chart-title">
            <h2>事项运行情况</h2>
          </div>
          <div class="chart-content">
            <v-citymap :opt="optMap" mapId="cityMap"></v-citymap>
          </div>
        </div>
      </a-col>
    </a-row>
  </div>
</template>

<script>
import VCitymap from '@/components/MapWuhu/Wuhumap.vue'
const mapData = [
  { 'name': '镜湖区', 'value': 457, 'attr': 'xzqh' },
  { 'name': '鸠江区', 'value': 342, 'attr': 'xzqh' },
  { 'name': '无为县', 'value': 273, 'attr': 'xzqh' },
  { 'name': '弋江区', 'value': 262, 'attr': 'xzqh' },
  { 'name': '繁昌县', 'value': 155, 'attr': 'xzqh' },
  { 'name': '南陵县', 'value': 91, 'attr': 'xzqh' },
  { 'name': '芜湖县', 'value': 88, 'attr': 'xzqh' },
  { 'name': '三山区', 'value': 56, 'attr': 'xzqh' }
]
export default {
  name: 'wuhuMap',
  components: {
    VCitymap
  },
  data () {
    return {
      optMap: {}
    }
  },
  mounted () {
    let numArray = []
    for (let i = 0; i < mapData.length; i++) {
      numArray.push(mapData[i].value)
    }
    let minNum = Math.min.apply(null, numArray)
    let maxNum = Math.max.apply(null, numArray)
    this.optMap = {
      data: mapData,
      minNum: minNum,
      maxNum: maxNum,
      unit: '人'
    }
  }
}
</script>

<style lang="less" scoped>
@import url("./index.less");
</style>
