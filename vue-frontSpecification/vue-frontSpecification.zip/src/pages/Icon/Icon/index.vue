<template>
  <div class="page-form">
    <a-card title="1.方向性图标">
     <ul>
       <li><a-icon type="step-backward"/><span class="anticon-class"><span class="ant-badge">step-backward</span></span></li>
      <li><a-icon type="step-forward"/><span class="anticon-class"><span class="ant-badge">step-forward</span></span></li>
      <li><a-icon type="fast-backward" /><span class="anticon-class"><span class="ant-badge">fast-backward</span></span></li>
      <li><a-icon type="fast-forward" /><span class="anticon-class"><span class="ant-badge">fast-forward</span></span></li>
      <li><a-icon type="shrink" /><span class="anticon-class"><span class="ant-badge">shrink</span></span></li>
      <li><a-icon type="arrows-alt" /><span class="anticon-class"><span class="ant-badge">arrows-alt</span></span></li>
      <li><a-icon type="down" /><span class="anticon-class"><span class="ant-badge">down</span></span></li>
      <li><a-icon type="up" /><span class="anticon-class"><span class="ant-badge">up</span></span></li>
      <li><a-icon type="left" /><span class="anticon-class"><span class="ant-badge">left</span></span></li>
      <li><a-icon type="right" /><span class="anticon-class"><span class="ant-badge">right</span></span></li>
      <li><a-icon type="caret-up" /><span class="anticon-class"><span class="ant-badge">caret-up</span></span></li>
      <li><a-icon type="caret-down" /><span class="anticon-class"><span class="ant-badge">caret-down</span></span></li>
      <li><a-icon type="caret-left" /><span class="anticon-class"><span class="ant-badge">caret-left</span></span></li>
      <li><a-icon type="caret-right" /><span class="anticon-class"><span class="ant-badge">caret-right</span></span></li>
      <li><a-icon type="up-circle" /><span class="anticon-class"><span class="ant-badge">up-circle</span></span></li>
      <li><a-icon type="down-circle" /><span class="anticon-class"><span class="ant-badge">down-circle</span></span></li>
      <li><a-icon type="left-circle" /><span class="anticon-class"><span class="ant-badge">left-circle</span></span></li>
      <li><a-icon type="right-circle" /><span class="anticon-class"><span class="ant-badge">right-circle</span></span></li>
      <li><a-icon type="double-right" /><span class="anticon-class"><span class="ant-badge">double-right</span></span></li>
      <li><a-icon type="double-left" /><span class="anticon-class"><span class="ant-badge">double-left</span></span></li>
      <li><a-icon type="vertical-left" /><span class="anticon-class"><span class="ant-badge">vertical-left"</span></span></li>
      <li><a-icon type="vertical-right" /><span class="anticon-class"><span class="ant-badge">vertical-right</span></span></li>
      <li><a-icon type="forward" /><span class="anticon-class"><span class="ant-badge">forward</span></span></li>
      <li><a-icon type="backward" /><span class="anticon-class"><span class="ant-badge">backward</span></span></li>
      <li><a-icon type="rollback" /><span class="anticon-class"><span class="ant-badge">rollback</span></span></li>
      <li><a-icon type="enter" /><span class="anticon-class"><span class="ant-badge">enter</span></span></li>
      <li><a-icon type="retweet" /><span class="anticon-class"><span class="ant-badge">retweet</span></span></li>
      <li><a-icon type="swap" /><span class="anticon-class"><span class="ant-badge">swap</span></span></li>
      <li><a-icon type="swap-left" /><span class="anticon-class"><span class="ant-badge">swap-left</span></span></li>
      <li><a-icon type="swap-right" /><span class="anticon-class"><span class="ant-badge">swap-right</span></span></li>
      <li><a-icon type="arrow-up" /><span class="anticon-class"><span class="ant-badge">arrow-up</span></span></li>
      <li><a-icon type="arrow-down" /><span class="anticon-class"><span class="ant-badge">arrow-down</span></span></li>
      <li><a-icon type="arrow-left" /><span class="anticon-class"><span class="ant-badge">arrow-left</span></span></li>
      <li><a-icon type="arrow-right" /><span class="anticon-class"><span class="ant-badge">arrow-right</span></span></li>
      <li><a-icon type="play-circle" /><span class="anticon-class"><span class="ant-badge">play-circle</span></span></li>
      <li><a-icon type="up-square" /><span class="anticon-class"><span class="ant-badge">up-square</span></span></li>
      <li><a-icon type="down-square" /><span class="anticon-class"><span class="ant-badge">down-square</span></span></li>
      <li><a-icon type="left-square" /><span class="anticon-class"><span class="ant-badge">left-square</span></span></li>
      <li><a-icon type="right-square" /><span class="anticon-class"><span class="ant-badge">right-square</span></span></li>
      <li><a-icon type="login" /><span class="anticon-class"><span class="ant-badge">login</span></span></li>
      <li><a-icon type="logout" /><span class="anticon-class"><span class="ant-badge">logout</span></span></li>
      <li><a-icon type="menu-fold" /><span class="anticon-class"><span class="ant-badge">menu-fold</span></span></li>
      <li><a-icon type="menu-unfold" /><span class="anticon-class"><span class="ant-badge">menu-unfold</span></span></li>
      <li><a-icon type="border-bottom" /><span class="anticon-class"><span class="ant-badge">border-bottom</span></span></li>
      <li><a-icon type="border-horizontal" /><span class="anticon-class"><span class="ant-badge">border-horizontal</span></span></li>
      <li><a-icon type="border-inner" /><span class="anticon-class"><span class="ant-badge">border-inner</span></span></li>
      <li><a-icon type="border-left" /><span class="anticon-class"><span class="ant-badge">border-left</span></span></li>
      <li><a-icon type="border-right" /><span class="anticon-class"><span class="ant-badge">border-right</span></span></li>
      <li><a-icon type="border-top" /><span class="anticon-class"><span class="ant-badge">border-top</span></span></li>
      <li><a-icon type="border-verticle" /><span class="anticon-class"><span class="ant-badge">border-verticle</span></span></li>
      <li><a-icon type="pic-center" /><span class="anticon-class"><span class="ant-badge">pic-center</span></span></li>
      <li><a-icon type="pic-left" /><span class="anticon-class"><span class="ant-badge">pic-left</span></span></li>
      <li><a-icon type="pic-right" /><span class="anticon-class"><span class="ant-badge">pic-right</span></span></li>
      <li><a-icon type="radius-bottomleft" /><span class="anticon-class"><span class="ant-badge">radius-bottomleft</span></span></li>
      <li><a-icon type="radius-bottomright" /><span class="anticon-class"><span class="ant-badge">radius-bottomright</span></span></li>
      <li><a-icon type="radius-upleft" /><span class="anticon-class"><span class="ant-badge">radius-upleft</span></span></li>
      <li><a-icon type="fullscreen" /><span class="anticon-class"><span class="ant-badge">fullscreen</span></span></li>
      <li><a-icon type="fullscreen-exit" /><span class="anticon-class"><span class="ant-badge">fullscreen-exit</span></span></li>
     </ul>
    </a-card>

    <a-card title="2.提示建议性图标">
     <ul>
       <li><a-icon type="question" /><span class="anticon-class"><span class="ant-badge">question</span></span></li>
       <li><a-icon type="question-circle" /><span class="anticon-class"><span class="ant-badge">question-circle</span></span></li>
       <li><a-icon type="plus" /><span class="anticon-class"><span class="ant-badge">plus</span></span></li>
       <li><a-icon type="plus-circle" /><span class="anticon-class"><span class="ant-badge">plus-circle</span></span></li>
       <li><a-icon type="pause" /><span class="anticon-class"><span class="ant-badge">pause</span></span></li>
       <li><a-icon type="pause-circle" /><span class="anticon-class"><span class="ant-badge">pause-circle</span></span></li>
       <li><a-icon type="minus" /><span class="anticon-class"><span class="ant-badge">minus</span></span></li>
       <li><a-icon type="minus-circle" /><span class="anticon-class"><span class="ant-badge">minus-circle</span></span></li>
       <li><a-icon type="plus-square" /><span class="anticon-class"><span class="ant-badge">plus-square</span></span></li>
       <li><a-icon type="minus-square" /><span class="anticon-class"><span class="ant-badge">minus-square</span></span></li>
       <li><a-icon type="info" /><span class="anticon-class"><span class="ant-badge">info</span></span></li>
       <li><a-icon type="info-circle" /><span class="anticon-class"><span class="ant-badge">info-circle</span></span></li>
       <li><a-icon type="exclamation" /><span class="anticon-class"><span class="ant-badge">exclamation</span></span></li>
       <li><a-icon type="exclamation-circle" /><span class="anticon-class"><span class="ant-badge">exclamation-circle</span></span></li>
       <li><a-icon type="close" /><span class="anticon-class"><span class="ant-badge">close</span></span></li>
       <li><a-icon type="close-circle" /><span class="anticon-class"><span class="ant-badge">close-circle</span></span></li>
       <li><a-icon type="close-square" /><span class="anticon-class"><span class="ant-badge">close-square</span></span></li>
       <li><a-icon type="check" /><span class="anticon-class"><span class="ant-badge">check</span></span></li>
       <li><a-icon type="check-circle" /><span class="anticon-class"><span class="ant-badge">check-circle</span></span></li>
       <li><a-icon type="check-square" /><span class="anticon-class"><span class="ant-badge">check-square</span></span></li>
       <li><a-icon type="clock-circle" /><span class="anticon-class"><span class="ant-badge">clock-circle</span></span></li>
       <li><a-icon type="warning" /><span class="anticon-class"><span class="ant-badge">warning</span></span></li>
       <li><a-icon type="issues-close" /><span class="anticon-class"><span class="ant-badge">issues-close</span></span></li>
       <li><a-icon type="stop" /><span class="anticon-class"><span class="ant-badge">stop</span></span></li>
     </ul>
    </a-card>

    <a-card title="3.编辑类图标">
     <ul>
       <li><a-icon type="edit" /><span class="anticon-class"><span class="ant-badge">edit</span></span></li>
       <li><a-icon type="form" /><span class="anticon-class"><span class="ant-badge">form</span></span></li>
       <li><a-icon type="copy" /><span class="anticon-class"><span class="ant-badge">copy</span></span></li>
       <li><a-icon type="scissor" /><span class="anticon-class"><span class="ant-badge">scissor</span></span></li>
       <li><a-icon type="delete" /><span class="anticon-class"><span class="ant-badge">delete</span></span></li>
       <li><a-icon type="snippets" /><span class="anticon-class"><span class="ant-badge">snippets</span></span></li>
       <li><a-icon type="diff" /><span class="anticon-class"><span class="ant-badge">diff</span></span></li>
       <li><a-icon type="highlight" /><span class="anticon-class"><span class="ant-badge">highlight</span></span></li>
       <li><a-icon type="align-center" /><span class="anticon-class"><span class="ant-badge">align-center</span></span></li>
       <li><a-icon type="align-left" /><span class="anticon-class"><span class="ant-badge">align-left</span></span></li>
       <li><a-icon type="align-right" /><span class="anticon-class"><span class="ant-badge">align-right</span></span></li>
       <li><a-icon type="bg-colors" /><span class="anticon-class"><span class="ant-badge">bg-colors</span></span></li>
       <li><a-icon type="bold" /><span class="anticon-class"><span class="ant-badge">bold</span></span></li>
       <li><a-icon type="italic" /><span class="anticon-class"><span class="ant-badge">italic</span></span></li>
       <li><a-icon type="underline" /><span class="anticon-class"><span class="ant-badge">underline</span></span></li>
       <li><a-icon type="strikethrough" /><span class="anticon-class"><span class="ant-badge">strikethrough</span></span></li>
       <li><a-icon type="redo" /><span class="anticon-class"><span class="ant-badge">redo</span></span></li>
       <li><a-icon type="undo" /><span class="anticon-class"><span class="ant-badge">undo</span></span></li>
       <li><a-icon type="zoom-in" /><span class="anticon-class"><span class="ant-badge">zoom-in</span></span></li>
       <li><a-icon type="zoom-out" /><span class="anticon-class"><span class="ant-badge">zoom-out</span></span></li>
       <li><a-icon type="font-colors" /><span class="anticon-class"><span class="ant-badge">font-colors</span></span></li>
       <li><a-icon type="font-size" /><span class="anticon-class"><span class="ant-badge">font-size</span></span></li>
       <li><a-icon type="line-height" /><span class="anticon-class"><span class="ant-badge">line-height</span></span></li>
       <li><a-icon type="colum-height" /><span class="anticon-class"><span class="ant-badge">colum-height</span></span></li>
       <li><a-icon type="dash" /><span class="anticon-class"><span class="ant-badge">dash</span></span></li>
       <li><a-icon type="small-dash" /><span class="anticon-class"><span class="ant-badge">small-dash</span></span></li>
       <li><a-icon type="sort-ascending" /><span class="anticon-class"><span class="ant-badge">sort-ascending</span></span></li>
       <li><a-icon type="sort-descending" /><span class="anticon-class"><span class="ant-badge">sort-descending</span></span></li>
       <li><a-icon type="drag" /><span class="anticon-class"><span class="ant-badge">drag</span></span></li>
       <li><a-icon type="ordered-list" /><span class="anticon-class"><span class="ant-badge">ordered-list</span></span></li>
       <li><a-icon type="radius-setting" /><span class="anticon-class"><span class="ant-badge">radius-setting</span></span></li>
     </ul>
    </a-card>

    <a-card title="4.数据类图标">
      <ul>
       <li><a-icon type="area-chart" /><span class="anticon-class"><span class="ant-badge">area-chart</span></span></li>
       <li><a-icon type="pie-chart" /><span class="anticon-class"><span class="ant-badge">pie-chart</span></span></li>
       <li><a-icon type="bar-chart" /><span class="anticon-class"><span class="ant-badge">bar-chart</span></span></li>
       <li><a-icon type="dot-chart" /><span class="anticon-class"><span class="ant-badge">dot-chart</span></span></li>
       <li><a-icon type="line-chart" /><span class="anticon-class"><span class="ant-badge">line-chart</span></span></li>
       <li><a-icon type="radar-chart" /><span class="anticon-class"><span class="ant-badge">radar-chart</span></span></li>
       <li><a-icon type="heat-map" /><span class="anticon-class"><span class="ant-badge">heat-map</span></span></li>
       <li><a-icon type="fall" /><span class="anticon-class"><span class="ant-badge">fall</span></span></li>
       <li><a-icon type="rise" /><span class="anticon-class"><span class="ant-badge">rise</span></span></li>
       <li><a-icon type="stock" /><span class="anticon-class"><span class="ant-badge">stock</span></span></li>
       <li><a-icon type="box-plot" /><span class="anticon-class"><span class="ant-badge">box-plot</span></span></li>
       <li><a-icon type="fund" /><span class="anticon-class"><span class="ant-badge">fund</span></span></li>
       <li><a-icon type="sliders" /><span class="anticon-class"><span class="ant-badge">sliders</span></span></li>
      </ul>
    </a-card>

    <a-card title="5.网站通用图标">
     <ul>
       <li><a-icon type="lock" /><span class="anticon-class"><span class="ant-badge">lock</span></span></li>
       <li><a-icon type="unlock" /><span class="anticon-class"><span class="ant-badge">unlock</span></span></li>
       <li><a-icon type="book" /><span class="anticon-class"><span class="ant-badge">book</span></span></li>
       <li><a-icon type="bars" /><span class="anticon-class"><span class="ant-badge">bars</span></span></li>
       <li><a-icon type="calendar" /><span class="anticon-class"><span class="ant-badge">calendar</span></span></li>
       <li><a-icon type="cloud" /><span class="anticon-class"><span class="ant-badge">cloud</span></span></li>
       <li><a-icon type="cloud-download" /><span class="anticon-class"><span class="ant-badge">cloud-download</span></span></li>
       <li><a-icon type="code" /><span class="anticon-class"><span class="ant-badge">code</span></span></li>
       <li><a-icon type="copy" /><span class="anticon-class"><span class="ant-badge">copy</span></span></li>
       <li><a-icon type="credit-card" /><span class="anticon-class"><span class="ant-badge">credit-card</span></span></li>
       <li><a-icon type="delete" /><span class="anticon-class"><span class="ant-badge">delete</span></span></li>
       <li><a-icon type="desktop" /><span class="anticon-class"><span class="ant-badge">desktop</span></span></li>
       <li><a-icon type="download" /><span class="anticon-class"><span class="ant-badge">download</span></span></li>
       <li><a-icon type="ellipsis" /><span class="anticon-class"><span class="ant-badge">ellipsis</span></span></li>
       <li><a-icon type="file" /><span class="anticon-class"><span class="ant-badge">file</span></span></li>
       <li><a-icon type="file-text" /><span class="anticon-class"><span class="ant-badge">file-text</span></span></li>
       <li><a-icon type="file-unknown" /><span class="anticon-class"><span class="ant-badge">file-unknown</span></span></li>
       <li><a-icon type="file-pdf" /><span class="anticon-class"><span class="ant-badge">file-pdf</span></span></li>
       <li><a-icon type="file-word" /><span class="anticon-class"><span class="ant-badge">file-word</span></span></li>
       <li><a-icon type="file-excel" /><span class="anticon-class"><span class="ant-badge">file-excel</span></span></li>
       <li><a-icon type="file-jpg" /><span class="anticon-class"><span class="ant-badge">file-jpg</span></span></li>
       <li><a-icon type="file-ppt" /><span class="anticon-class"><span class="ant-badge">file-ppt</span></span></li>
       <li><a-icon type="file-markdown" /><span class="anticon-class"><span class="ant-badge">file-markdown</span></span></li>
       <li><a-icon type="file-add" /><span class="anticon-class"><span class="ant-badge">file-add</span></span></li>
       <li><a-icon type="folder" /><span class="anticon-class"><span class="ant-badge">folder</span></span></li>
       <li><a-icon type="folder-open" /><span class="anticon-class"><span class="ant-badge">folder-open</span></span></li>
       <li><a-icon type="folder-add" /><span class="anticon-class"><span class="ant-badge">folder-add</span></span></li>
       <li><a-icon type="hdd" /><span class="anticon-class"><span class="ant-badge">hdd</span></span></li>
       <li><a-icon type="frown" /><span class="anticon-class"><span class="ant-badge">frown</span></span></li>
       <li><a-icon type="meh" /><span class="anticon-class"><span class="ant-badge">meh</span></span></li>
       <li><a-icon type="smile" /><span class="anticon-class"><span class="ant-badge">smile</span></span></li>
       <li><a-icon type="inbox" /><span class="anticon-class"><span class="ant-badge">inbox</span></span></li>
       <li><a-icon type="laptop" /><span class="anticon-class"><span class="ant-badge">laptop</span></span></li>
       <li><a-icon type="appstore" /><span class="anticon-class"><span class="ant-badge">appstore</span></span></li>
       <li><a-icon type="link" /><span class="anticon-class"><span class="ant-badge">link</span></span></li>
       <li><a-icon type="mail" /><span class="anticon-class"><span class="ant-badge">mail</span></span></li>
       <li><a-icon type="mobile" /><span class="anticon-class"><span class="ant-badge">mobile</span></span></li>
       <li><a-icon type="notification" /><span class="anticon-class"><span class="ant-badge">notification</span></span></li>
       <li><a-icon type="paper-clip" /><span class="anticon-class"><span class="ant-badge">paper-clip</span></span></li>
       <li><a-icon type="picture" /><span class="anticon-class"><span class="ant-badge">picture</span></span></li>
       <li><a-icon type="poweroff" /><span class="anticon-class"><span class="ant-badge">poweroff</span></span></li>
       <li><a-icon type="reload" /><span class="anticon-class"><span class="ant-badge">reload</span></span></li>
       <li><a-icon type="search" /><span class="anticon-class"><span class="ant-badge">search</span></span></li>
       <li><a-icon type="setting" /><span class="anticon-class"><span class="ant-badge">setting</span></span></li>
       <li><a-icon type="share-alt" /><span class="anticon-class"><span class="ant-badge">share-alt</span></span></li>
       <li><a-icon type="shopping-cart" /><span class="anticon-class"><span class="ant-badge">shopping-cart</span></span></li>
       <li><a-icon type="tablet" /><span class="anticon-class"><span class="ant-badge">tablet</span></span></li>
       <li><a-icon type="tag" /><span class="anticon-class"><span class="ant-badge">tag</span></span></li>
       <li><a-icon type="tags" /><span class="anticon-class"><span class="ant-badge">tags</span></span></li>
       <li><a-icon type="to-top" /><span class="anticon-class"><span class="ant-badge">to-top</span></span></li>
       <li><a-icon type="upload" /><span class="anticon-class"><span class="ant-badge">upload</span></span></li>
       <li><a-icon type="user" /><span class="anticon-class"><span class="ant-badge">user</span></span></li>
       <li><a-icon type="video-camera" /><span class="anticon-class"><span class="ant-badge">video-camera</span></span></li>
       <li><a-icon type="home" /><span class="anticon-class"><span class="ant-badge">home</span></span></li>
       <li><a-icon type="loading" /><span class="anticon-class"><span class="ant-badge">loading</span></span></li>
       <li><a-icon type="loading-3-quarters" /><span class="anticon-class"><span class="ant-badge">loading-3-quarters</span></span></li>
       <li><a-icon type="cloud-upload" /><span class="anticon-class"><span class="ant-badge">cloud-upload</span></span></li>
       <li><a-icon type="star" /><span class="anticon-class"><span class="ant-badge">star</span></span></li>
       <li><a-icon type="heart" /><span class="anticon-class"><span class="ant-badge">heart</span></span></li>
       <li><a-icon type="environment" /><span class="anticon-class"><span class="ant-badge">environment</span></span></li>
       <li><a-icon type="eye" /><span class="anticon-class"><span class="ant-badge">eye</span></span></li>
       <li><a-icon type="eye-invisible" /><span class="anticon-class"><span class="ant-badge">eye-invisible</span></span></li>
       <li><a-icon type="camera" /><span class="anticon-class"><span class="ant-badge">camera</span></span></li>
       <li><a-icon type="save" /><span class="anticon-class"><span class="ant-badge">save</span></span></li>
       <li><a-icon type="team" /><span class="anticon-class"><span class="ant-badge">team</span></span></li>
       <li><a-icon type="solution" /><span class="anticon-class"><span class="ant-badge">solution</span></span></li>
       <li><a-icon type="phone" /><span class="anticon-class"><span class="ant-badge">phone</span></span></li>
       <li><a-icon type="filter" /><span class="anticon-class"><span class="ant-badge">filter</span></span></li>
       <li><a-icon type="exception" /><span class="anticon-class"><span class="ant-badge">exception</span></span></li>
       <li><a-icon type="export" /><span class="anticon-class"><span class="ant-badge">export</span></span></li>
       <li><a-icon type="customer-service" /><span class="anticon-class"><span class="ant-badge">customer-service</span></span></li>
       <li><a-icon type="qrcode" /><span class="anticon-class"><span class="ant-badge">qrcode</span></span></li>
       <li><a-icon type="scan" /><span class="anticon-class"><span class="ant-badge">scan</span></span></li>
       <li><a-icon type="like" /><span class="anticon-class"><span class="ant-badge">like</span></span></li>
       <li><a-icon type="dislike" /><span class="anticon-class"><span class="ant-badge">dislike</span></span></li>
       <li><a-icon type="message" /><span class="anticon-class"><span class="ant-badge">message</span></span></li>
       <li><a-icon type="pay-circle" /><span class="anticon-class"><span class="ant-badge">pay-circle</span></span></li>
       <li><a-icon type="calculator" /><span class="anticon-class"><span class="ant-badge">calculator</span></span></li>
       <li><a-icon type="pushpin" /><span class="anticon-class"><span class="ant-badge">pushpin</span></span></li>
       <li><a-icon type="bulb" /><span class="anticon-class"><span class="ant-badge">bulb</span></span></li>
       <li><a-icon type="select" /><span class="anticon-class"><span class="ant-badge">select</span></span></li>
       <li><a-icon type="switcher" /><span class="anticon-class"><span class="ant-badge">switcher</span></span></li>
       <li><a-icon type="rocket" /><span class="anticon-class"><span class="ant-badge">rocket</span></span></li>
       <li><a-icon type="bell" /><span class="anticon-class"><span class="ant-badge">bell</span></span></li>
       <li><a-icon type="disconnect" /><span class="anticon-class"><span class="ant-badge">disconnect</span></span></li>
       <li><a-icon type="database" /><span class="anticon-class"><span class="ant-badge">database</span></span></li>
       <li><a-icon type="compass" /><span class="anticon-class"><span class="ant-badge">compass</span></span></li>
       <li><a-icon type="barcode" /><span class="anticon-class"><span class="ant-badge">barcode</span></span></li>
       <li><a-icon type="hourglass" /><span class="anticon-class"><span class="ant-badge">hourglass</span></span></li>
       <li><a-icon type="key" /><span class="anticon-class"><span class="ant-badge">key</span></span></li>
       <li><a-icon type="flag" /><span class="anticon-class"><span class="ant-badge">flag</span></span></li>
       <li><a-icon type="layout" /><span class="anticon-class"><span class="ant-badge">layout</span></span></li>
       <li><a-icon type="printer" /><span class="anticon-class"><span class="ant-badge">printer</span></span></li>
       <li><a-icon type="sound" /><span class="anticon-class"><span class="ant-badge">sound</span></span></li>
       <li><a-icon type="usb" /><span class="anticon-class"><span class="ant-badge">usb</span></span></li>
       <li><a-icon type="skin" /><span class="anticon-class"><span class="ant-badge">skin</span></span></li>
       <li><a-icon type="tool" /><span class="anticon-class"><span class="ant-badge">tool</span></span></li>
       <li><a-icon type="sync" /><span class="anticon-class"><span class="ant-badge">sync</span></span></li>
       <li><a-icon type="wifi" /><span class="anticon-class"><span class="ant-badge">wifi</span></span></li>
       <li><a-icon type="car" /><span class="anticon-class"><span class="ant-badge">car</span></span></li>
       <li><a-icon type="schedule" /><span class="anticon-class"><span class="ant-badge">schedule</span></span></li>
       <li><a-icon type="user-add" /><span class="anticon-class"><span class="ant-badge">user-add</span></span></li>
       <li><a-icon type="user-delete" /><span class="anticon-class"><span class="ant-badge">user-delete</span></span></li>
       <li><a-icon type="usergroup-add" /><span class="anticon-class"><span class="ant-badge">usergroup-add</span></span></li>
       <li><a-icon type="usergroup-delete" /><span class="anticon-class"><span class="ant-badge">usergroup-delete</span></span></li>
       <li><a-icon type="man" /><span class="anticon-class"><span class="ant-badge">man</span></span></li>
       <li><a-icon type="woman" /><span class="anticon-class"><span class="ant-badge">woman</span></span></li>
       <li><a-icon type="shop" /><span class="anticon-class"><span class="ant-badge">shop</span></span></li>
       <li><a-icon type="gift" /><span class="anticon-class"><span class="ant-badge">gift</span></span></li>
       <li><a-icon type="idcard" /><span class="anticon-class"><span class="ant-badge">idcard</span></span></li>
       <li><a-icon type="medicine-box" /><span class="anticon-class"><span class="ant-badge">medicine-box</span></span></li>
       <li><a-icon type="red-envelope" /><span class="anticon-class"><span class="ant-badge">red-envelope</span></span></li>
       <li><a-icon type="coffee" /><span class="anticon-class"><span class="ant-badge">coffee</span></span></li>
       <li><a-icon type="copyright" /><span class="anticon-class"><span class="ant-badge">copyright</span></span></li>
       <li><a-icon type="trademark" /><span class="anticon-class"><span class="ant-badge">trademark</span></span></li>
       <li><a-icon type="safety" /><span class="anticon-class"><span class="ant-badge">safety</span></span></li>
       <li><a-icon type="wallet" /><span class="anticon-class"><span class="ant-badge">wallet</span></span></li>
       <li><a-icon type="bank" /><span class="anticon-class"><span class="ant-badge">bank</span></span></li>
       <li><a-icon type="trophy" /><span class="anticon-class"><span class="ant-badge">trophy</span></span></li>
       <li><a-icon type="contacts" /><span class="anticon-class"><span class="ant-badge">contacts</span></span></li>
       <li><a-icon type="global" /><span class="anticon-class"><span class="ant-badge">global</span></span></li>
       <li><a-icon type="shake" /><span class="anticon-class"><span class="ant-badge">shake</span></span></li>
       <li><a-icon type="api" /><span class="anticon-class"><span class="ant-badge">api</span></span></li>
       <li><a-icon type="fork" /><span class="anticon-class"><span class="ant-badge">fork</span></span></li>
       <li><a-icon type="dashboard" /><span class="anticon-class"><span class="ant-badge">dashboard</span></span></li>
       <li><a-icon type="table" /><span class="anticon-class"><span class="ant-badge">table</span></span></li>
       <li><a-icon type="profile" /><span class="anticon-class"><span class="ant-badge">profile</span></span></li>
       <li><a-icon type="alert" /><span class="anticon-class"><span class="ant-badge">alert</span></span></li>
       <li><a-icon type="audit" /><span class="anticon-class"><span class="ant-badge">audit</span></span></li>
       <li><a-icon type="branches" /><span class="anticon-class"><span class="ant-badge">branches</span></span></li>
       <li><a-icon type="build" /><span class="anticon-class"><span class="ant-badge">build</span></span></li>
       <li><a-icon type="border" /><span class="anticon-class"><span class="ant-badge">border</span></span></li>
       <li><a-icon type="crown" /><span class="anticon-class"><span class="ant-badge">crown</span></span></li>
       <li><a-icon type="experiment" /><span class="anticon-class"><span class="ant-badge">experiment</span></span></li>
       <li><a-icon type="fire" /><span class="anticon-class"><span class="ant-badge">fire</span></span></li>
       <li><a-icon type="money-collect" /><span class="anticon-class"><span class="ant-badge">money-collect</span></span></li>
       <li><a-icon type="property-safety" /><span class="anticon-class"><span class="ant-badge">property-safety</span></span></li>
       <li><a-icon type="read" /><span class="anticon-class"><span class="ant-badge">read</span></span></li>
       <li><a-icon type="reconciliation" /><span class="anticon-class"><span class="ant-badge">reconciliation</span></span></li>
       <li><a-icon type="rest" /><span class="anticon-class"><span class="ant-badge">rest</span></span></li>
       <li><a-icon type="security-scan" /><span class="anticon-class"><span class="ant-badge">security-scan</span></span></li>
       <li><a-icon type="insurance" /><span class="anticon-class"><span class="ant-badge">insurance</span></span></li>
       <li><a-icon type="interation" /><span class="anticon-class"><span class="ant-badge">interation</span></span></li>
       <li><a-icon type="safety-certificate" /><span class="anticon-class"><span class="ant-badge">safety-certificate</span></span></li>
       <li><a-icon type="project" /><span class="anticon-class"><span class="ant-badge">project</span></span></li>
       <li><a-icon type="thunderbolt" /><span class="anticon-class"><span class="ant-badge">thunderbolt</span></span></li>
       <li><a-icon type="block" /><span class="anticon-class"><span class="ant-badge">block</span></span></li>
       <li><a-icon type="cluster" /><span class="anticon-class"><span class="ant-badge">cluster</span></span></li>
       <li><a-icon type="deployment-unit" /><span class="anticon-class"><span class="ant-badge">deployment-unit</span></span></li>
       <li><a-icon type="dollar" /><span class="anticon-class"><span class="ant-badge">dollar</span></span></li>
       <li><a-icon type="euro" /><span class="anticon-class"><span class="ant-badge">euro</span></span></li>
       <li><a-icon type="pound" /><span class="anticon-class"><span class="ant-badge">pound</span></span></li>
       <li><a-icon type="file-done" /><span class="anticon-class"><span class="ant-badge">file-done</span></span></li>
       <li><a-icon type="file-exclamation" /><span class="anticon-class"><span class="ant-badge">file-exclamation</span></span></li>
       <li><a-icon type="file-protect" /><span class="anticon-class"><span class="ant-badge">file-protect</span></span></li>
       <li><a-icon type="file-search" /><span class="anticon-class"><span class="ant-badge">file-search</span></span></li>
       <li><a-icon type="file-sync" /><span class="anticon-class"><span class="ant-badge">file-sync</span></span></li>
       <li><a-icon type="gateway" /><span class="anticon-class"><span class="ant-badge">gateway</span></span></li>
       <li><a-icon type="gold" /><span class="anticon-class"><span class="ant-badge">gold</span></span></li>
       <li><a-icon type="robot" /><span class="anticon-class"><span class="ant-badge">robot</span></span></li>
       <li><a-icon type="shopping" /><span class="anticon-class"><span class="ant-badge">shopping</span></span></li>
     </ul>
    </a-card>
    <a-card title="6.品牌和标识">
      <ul>
       <li><a-icon type="android" /><span class="anticon-class"><span class="ant-badge">android</span></span></li>
       <li><a-icon type="apple" /><span class="anticon-class"><span class="ant-badge">apple</span></span></li>
       <li><a-icon type="windows" /><span class="anticon-class"><span class="ant-badge">windows</span></span></li>
       <li><a-icon type="ie" /><span class="anticon-class"><span class="ant-badge">ie</span></span></li>
       <li><a-icon type="chrome" /><span class="anticon-class"><span class="ant-badge">chrome</span></span></li>
       <li><a-icon type="github" /><span class="anticon-class"><span class="ant-badge">github</span></span></li>
       <li><a-icon type="aliwangwang" /><span class="anticon-class"><span class="ant-badge">aliwangwang</span></span></li>
       <li><a-icon type="dingding" /><span class="anticon-class"><span class="ant-badge">dingding</span></span></li>
       <li><a-icon type="weibo-square" /><span class="anticon-class"><span class="ant-badge">weibo-square</span></span></li>
       <li><a-icon type="weibo-circle" /><span class="anticon-class"><span class="ant-badge">weibo-circle</span></span></li>
       <li><a-icon type="taobao-circle" /><span class="anticon-class"><span class="ant-badge">taobao-circle</span></span></li>
       <li><a-icon type="html5" /><span class="anticon-class"><span class="ant-badge">html5</span></span></li>
       <li><a-icon type="weibo" /><span class="anticon-class"><span class="ant-badge">weibo</span></span></li>
       <li><a-icon type="twitter" /><span class="anticon-class"><span class="ant-badge">twitter</span></span></li>
       <li><a-icon type="wechat" /><span class="anticon-class"><span class="ant-badge">wechat</span></span></li>
       <li><a-icon type="youtube" /><span class="anticon-class"><span class="ant-badge">youtube</span></span></li>
       <li><a-icon type="alipay-circle" /><span class="anticon-class"><span class="ant-badge">alipay-circle</span></span></li>
       <li><a-icon type="taobao" /><span class="anticon-class"><span class="ant-badge">taobao</span></span></li>
       <li><a-icon type="skype" /><span class="anticon-class"><span class="ant-badge">skype</span></span></li>
       <li><a-icon type="qq" /><span class="anticon-class"><span class="ant-badge">qq</span></span></li>
       <li><a-icon type="medium-workmark" /><span class="anticon-class"><span class="ant-badge">medium-workmark</span></span></li>
       <li><a-icon type="gitlab" /><span class="anticon-class"><span class="ant-badge">gitlab</span></span></li>
       <li><a-icon type="medium" /><span class="anticon-class"><span class="ant-badge">medium</span></span></li>
       <li><a-icon type="linkedin" /><span class="anticon-class"><span class="ant-badge">linkedin</span></span></li>
       <li><a-icon type="google-plus" /><span class="anticon-class"><span class="ant-badge">google-plus</span></span></li>
       <li><a-icon type="dropbox" /><span class="anticon-class"><span class="ant-badge">dropbox</span></span></li>
       <li><a-icon type="facebook" /><span class="anticon-class"><span class="ant-badge">facebook</span></span></li>
       <li><a-icon type="codepen" /><span class="anticon-class"><span class="ant-badge">codepen</span></span></li>
       <li><a-icon type="code-sandbox" /><span class="anticon-class"><span class="ant-badge">code-sandbox</span></span></li>
       <li><a-icon type="amazon" /><span class="anticon-class"><span class="ant-badge">amazon</span></span></li>
       <li><a-icon type="google" /><span class="anticon-class"><span class="ant-badge">google</span></span></li>
       <li><a-icon type="codepen-circle" /><span class="anticon-class"><span class="ant-badge">codepen-circle</span></span></li>
       <li><a-icon type="alipay" /><span class="anticon-class"><span class="ant-badge">alipay</span></span></li>
       <li><a-icon type="ant-design" /><span class="anticon-class"><span class="ant-badge">ant-design</span></span></li>
       <li><a-icon type="aliyun" /><span class="anticon-class"><span class="ant-badge">aliyun</span></span></li>
       <li><a-icon type="zhihu" /><span class="anticon-class"><span class="ant-badge">zhihu</span></span></li>
       <li><a-icon type="slack" /><span class="anticon-class"><span class="ant-badge">slack</span></span></li>
       <li><a-icon type="slack-square" /><span class="anticon-class"><span class="ant-badge">slack-square</span></span></li>
       <li><a-icon type="behance" /><span class="anticon-class"><span class="ant-badge">behance</span></span></li>
       <li><a-icon type="behance-square" /><span class="anticon-class"><span class="ant-badge">behance-square</span></span></li>
       <li><a-icon type="dribbble" /><span class="anticon-class"><span class="ant-badge">dribbble</span></span></li>
       <li><a-icon type="dribbble-square" /><span class="anticon-class"><span class="ant-badge">dribbble-square</span></span></li>
       <li><a-icon type="instagram" /><span class="anticon-class"><span class="ant-badge">instagram</span></span></li>
       <li><a-icon type="yuque" /><span class="anticon-class"><span class="ant-badge">yuque</span></span></li>
       <li><a-icon type="alibaba" /><span class="anticon-class"><span class="ant-badge">alibaba</span></span></li>
       <li><a-icon type="yahoo" /><span class="anticon-class"><span class="ant-badge">yahoo</span></span></li>
      </ul>
    </a-card>
    <a-card title="7.基本用法">
      <div class="icons-list">
        <a-icon type="home" />
        <a-icon type="setting" theme="filled" />
        <a-icon type="smile" theme="outlined" />
        <a-icon type="sync" spin />
        <a-icon type="smile" :rotate="180" />
        <a-icon type="loading" />
      </div>
    </a-card>
    <a-card title="8.自定义图标">
      <div class="custom-icons-list">
        <heart-icon :style="{ color: 'hotpink' }" />
        <panda-icon :style="{ fontSize: '32px' }" />
      </div>
    </a-card>
    <a-card title="9.使用 iconfont.cn">
        <div class="icons-list">
          <icon-font type="icon-tuichu" />
          <icon-font type="icon-facebook" />
          <icon-font type="icon-twitter" />
        </div>
    </a-card>
    <a-card title="10.多色图标">
        <div class="icons-list">
          <a-icon type="smile" theme="twoTone" />
          <a-icon type="heart" theme="twoTone" twoToneColor="#eb2f96" />
          <a-icon type="check-circle" theme="twoTone" twoToneColor="#52c41a" />
        </div>
    </a-card>
  </div>
</template>

<script>
import GlobalMixin from '@/mixins/global'
import { Icon } from 'ant-design-vue'
const IconFont = Icon.createFromIconfontCN({
  scriptUrl: '//at.alicdn.com/t/font_8d5l8fzk5b87iudi.js'
})
const HeartSvg = {
  template: `
    <svg width="1em" height="1em" fill="currentColor" viewBox="0 0 1024 1024">
      <path d="M923 283.6c-13.4-31.1-32.6-58.9-56.9-82.8-24.3-23.8-52.5-42.4-84-55.5-32.5-13.5-66.9-20.3-102.4-20.3-49.3 0-97.4 13.5-139.2 39-10 6.1-19.5 12.8-28.5 20.1-9-7.3-18.5-14-28.5-20.1-41.8-25.5-89.9-39-139.2-39-35.5 0-69.9 6.8-102.4 20.3-31.4 13-59.7 31.7-84 55.5-24.4 23.9-43.5 51.7-56.9 82.8-13.9 32.3-21 66.6-21 101.9 0 33.3 6.8 68 20.3 103.3 11.3 29.5 27.5 60.1 48.2 91 32.8 48.9 77.9 99.9 133.9 151.6 92.8 85.7 184.7 144.9 188.6 147.3l23.7 15.2c10.5 6.7 24 6.7 34.5 0l23.7-15.2c3.9-2.5 95.7-61.6 188.6-147.3 56-51.7 101.1-102.7 133.9-151.6 20.7-30.9 37-61.5 48.2-91 13.5-35.3 20.3-70 20.3-103.3 0.1-35.3-7-69.6-20.9-101.9z" />
    </svg>
  `
}
const PandaSvg = {
  template: `
    <svg viewBox="0 0 1024 1024" width="1em" height="1em" fill="currentColor">
      <path d="M99.096 315.634s-82.58-64.032-82.58-132.13c0-66.064 33.032-165.162 148.646-148.646 83.37 11.91 99.096 165.162 99.096 165.162l-165.162 115.614zM924.906 315.634s82.58-64.032 82.58-132.13c0-66.064-33.032-165.162-148.646-148.646-83.37 11.91-99.096 165.162-99.096 165.162l165.162 115.614z" fill="#6B676E" p-id="1143" />
      <path d="M1024 561.548c0 264.526-229.23 429.42-512.002 429.42S0 826.076 0 561.548 283.96 66.064 512.002 66.064 1024 297.022 1024 561.548z" fill="#FFEBD2" p-id="1144" />
      <path d="M330.324 842.126c0 82.096 81.34 148.646 181.678 148.646s181.678-66.55 181.678-148.646H330.324z" fill="#E9D7C3" p-id="1145" />
      <path d="M644.13 611.098C594.582 528.516 561.55 512 512.002 512c-49.548 0-82.58 16.516-132.13 99.096-42.488 70.814-78.73 211.264-49.548 247.742 66.064 82.58 165.162 33.032 181.678 33.032 16.516 0 115.614 49.548 181.678-33.032 29.18-36.476-7.064-176.93-49.55-247.74z" fill="#FFFFFF" p-id="1146" />
      <path d="M611.098 495.484c0-45.608 36.974-82.58 82.58-82.58 49.548 0 198.194 99.098 198.194 165.162s-79.934 144.904-148.646 99.096c-49.548-33.032-132.128-148.646-132.128-181.678zM412.904 495.484c0-45.608-36.974-82.58-82.58-82.58-49.548 0-198.194 99.098-198.194 165.162s79.934 144.904 148.646 99.096c49.548-33.032 132.128-148.646 132.128-181.678z" fill="#6B676E" p-id="1147" />
      <path d="M512.002 726.622c-30.06 0-115.614 5.668-115.614 33.032 0 49.638 105.484 85.24 115.614 82.58 10.128 2.66 115.614-32.944 115.614-82.58-0.002-27.366-85.556-33.032-115.614-33.032z" fill="#464655" p-id="1148" />
      <path d="M330.324 495.484m-33.032 0a33.032 33.032 0 1 0 66.064 0 33.032 33.032 0 1 0-66.064 0Z" fill="#464655" p-id="1149" />
      <path d="M693.678 495.484m-33.032 0a33.032 33.032 0 1 0 66.064 0 33.032 33.032 0 1 0-66.064 0Z" fill="#464655" p-id="1150" />
    </svg>
  `
}
const HeartIcon = {
  template: `
    <a-icon :component="HeartSvg" />
  `,
  data () {
    return {
      HeartSvg
    }
  }
}

const PandaIcon = {
  template: `
    <a-icon :component="PandaSvg" />
  `,
  data () {
    return {
      PandaSvg
    }
  }
}
export default {
  name: 'DemoForm', // 表单
  components: {
    HeartIcon,
    PandaIcon,
    IconFont
  },
  mixins: [GlobalMixin],
  data () {
    return {
      userName: 'username'
    }
  },
  mounted () {},
  methods: {
    onSearch (value) {
      console.log(value)
    }
  }
}
</script>
<style lang="less" scoped>
@import "./index.less";
</style>
